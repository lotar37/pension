<?php
/* @var $this WarActionsController */
/* @var $model WarActions */

?>

<h1>Новое</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>