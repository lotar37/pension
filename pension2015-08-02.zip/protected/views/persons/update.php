<?php
/* @var $this PersonsController */
/* @var $model Persons */



?>


<?php 


$this->renderPartial('_form', array('model'=>$model)); 

?>