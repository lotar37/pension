<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>

<h1> <i><?php echo CHtml::encode(Yii::app()->name); ?></i></h1>


