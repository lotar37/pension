<?php
$a_age = explode("-",$conditions["age"]);
if(count($a_age)!==2){
	$a_age = array(0,120);
}
?>

<h1 id='h1_title'>
Пенсионные дела
</h1>
<style>
td{
		vertical-align:top;

}
th{
	background:#77bbea;
	text-align:center;
}
h6{
	color:#555;
}
table.search_result td{
	font-size:14px;
}
tr.act td{
	background:#00f;
}
table.search_form tr.actform td{
	background:#eea;
}
table.search_form td{
	font-size:18px;
	background:#e0e0e0;
	border:1px solid #d0d0d0;
	cursor:pointer;
}
input{
	font-size:18px;
}
select{
	border-radius: 8px;
	margin-left:0em;
}
#shift{
	background:#5ac;
}
td.filter{
	xborder:1px solid white;
}

.filter input[type="checkbox"] {
	height:0px;
	width:0px;
	overflow:hidden;
    padding:0px;
}
.filter td{	
 	background:#eee;
	xfont-size:10px;
	cursor:pointer;
    padding:0px;
}
#filter,#filter table, #filter table td{	
    padding:0px;
}
div,span,.filter{	
    padding:0px;
}
.filter span,.filter label, #client_filter_div{	
    padding:0px;
	margin:0em;
}
#format,  #gender, #warchaes, #paystop_div, #showall_div{ 
    margin-top: 1em; 
	padding:0px;
} 
.filter td.filterform{	
    padding:0px;
}
.eighty{
    border-spacing:5px;
}
.eighty td{
	text-align:center;
}
table.filter_body{
    padding:0px;	
}table.filter_body td{
    padding:0px;	
}
table.search_form td.in{background:#00f;}
table.search_form td.pk{background:#ff0;}
table.search_form td.vl{background:#800;}
table.search_form td.vv{background:#f50;}
table.search_form td.sp{background:#fff;}
table.search_form td.vz{background:#8ff;}

table.search_form tr.actform td.in{background:#00f;}
table.search_form tr.actform td.pk{background:#ff0;}
table.search_form tr.actform td.vl{background:#800;}
table.search_form tr.actform td.vv{background:#f50;}
table.search_form tr.actform td.sp{background:#fff;}
table.search_form tr.actform td.vz{background:#8ff;}

.paging{
	border-spacing: 7px;
	width:200px;
}
.paging td{
	padding:5px;
	margin:5px;
	!background:#ddd;
	cursor:pointer;
	vertical-align:center;
}
.paging td.active{
	padding:5px;
	margin:5px;
	!background:#ffb;
	cursor:pointer;
	font-size: 24px;
}

</style>
<script>
$(document).ready(function(){
var ajaxRequest;
$.ajaxSetup ({
    // Отменить кеширование AJAX запросов
    cache: false
});
$(".paging td").click(function(event){
	//alert($(this).attr("num"));
	
     ajaxRequest = $("#string").serialize();
     $('div#result2').load('loadSearchResult?'+ajaxRequest+"&noCache=" + (new Date().getTime()) + Math.random()+collechSearchCondition()+"&anch="+$(this).attr("num"));
});

$(".search_form input:checkbox").click(function(event){
	var len= $(".search_form input:checkbox:checked").length;
	if(len>0)$("#sol").css("display","");
	else $("#sol").css("display","none");
	$("#selected").html("Выбрано:"+ len);
	
});
$('#string').keyup(function(){
 //alert(123);	
   $("#h1_title").text("Пенсионные дела");
	//	$("#shiftcontent").text(">>");
  // $("#filter" ).hide("fast");
   ajaxRequest = $(this).serialize();
	//$("#result").show();
    $('div#result2').load('loadSearchResult?'+ajaxRequest+"&noCache=" + (new Date().getTime()) + Math.random()+collechSearchCondition());
	
 
})

$("table.search_form tr").mouseover(function(){
	$(this).addClass("actform");
});
$("table.search_form tr").mouseout(function(){
	$(this).removeClass("actform");
});
$("table.search_form tr").click(function(event){
		event.stopPropagation();
	    window.document.location.href='update/'+$(this).attr("num");	
});
$("#shift").click(function(event){
	if($('#filter').is(':visible')){
		$("#shiftcontent").text(">>");
		$(".filter td.filterform").css("padding","0px");
	}else{
		$("#shiftcontent").text("<<");
		$(".filter td.filterform").css("padding","5px");
	}
	$("#filter" ).toggle( "fast" );
    }
);
$(".eighty td").click(function(event){
	$("#h1_title").text("Пересчет восьмидесятилетних");
    $('div#result2').load('loadSearch80?shift='+$(this).attr("num"));
	$(".eighty td").css("border","0px solid red");
	$(this).css("border","1px solid red");
    
});
  $(function() {
    $( "#slider-range" ).slider({
      range: true,
      min: 0,
      max: 120,
      values: [ <?php echo $a_age[0];?>, <?php echo $a_age[1];?> ],
      slide: function( event, ui ) {
        $( "#amount" ).val( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
      },
	  
      click: function( event, ui ) {
          ajaxRequest = $("#string").serialize();
          $('div#result2').load('loadSearchResult?'+ajaxRequest+"&noCache=" + (new Date().getTime()) + Math.random()+collechSearchCondition());
	  }

    });
	
    $( "#amount" ).val( $( "#slider-range" ).slider( "values", 0 ) +
      " - " + $( "#slider-range" ).slider( "values", 1 ) );
  });
  $(function() {
    $("#terminated").button();
    $("#paystop").button();
    $("#checkwar").button();
	$("#checkchaes").button();
	$("#showall").button();
    $("#format").buttonset();
    $("#gender").buttonset();
  });
  $("#format input:checkbox, #gender input:checkbox, #showall, #paystop, #checkchaes, #terminated, #checkwar").click(function(event){
      ajaxRequest = $("#string").serialize();
      $('div#result2').load('loadSearchResult?'+ajaxRequest+"&noCache=" + (new Date().getTime()) + Math.random()+collechSearchCondition());
  });
  /*$("#gender input:checkbox").click(function(event){
      ajaxRequest = $("#string").serialize();
	  alert(collechSearchCondition());
      $('div#result2').load('loadSearchResult?'+ajaxRequest+"&noCache=" + (new Date().getTime()) + Math.random()+collechSearchCondition());
  });
  $("#checkwar").click(function(event){
      ajaxRequest = $("#string").serialize();
      $('div#result2').load('loadSearchResult?'+ajaxRequest+"&noCache=" + (new Date().getTime()) + Math.random()+collechSearchCondition());
  });
  $("#terminated").click(function(event){
      ajaxRequest = $("#string").serialize();
      $('div#result2').load('loadSearchResult?'+ajaxRequest+"&noCache=" + (new Date().getTime()) + Math.random()+collechSearchCondition());
  });
  $("#checkchaes").click(function(event){
      ajaxRequest = $("#string").serialize();
      $('div#result2').load('loadSearchResult?'+ajaxRequest+"&noCache=" + (new Date().getTime()) + Math.random()+collechSearchCondition());
  });
  $("#paystop").click(function(event){
      ajaxRequest = $("#string").serialize();
      $('div#result2').load('loadSearchResult?'+ajaxRequest+"&noCache=" + (new Date().getTime()) + Math.random()+collechSearchCondition());
  });
  $("#showall").click(function(event){
      ajaxRequest = $("#string").serialize();
      $('div#result2').load('loadSearchResult?'+ajaxRequest+"&noCache=" + (new Date().getTime()) + Math.random()+collechSearchCondition());
  });*/
  $("#slider-range").mouseup(function(event){
      ajaxRequest = $("#string").serialize();
      $('div#result2').load('loadSearchResult?'+ajaxRequest+"&noCache=" + (new Date().getTime()) + Math.random()+collechSearchCondition());
  });
  
  //  collechSearchConditions in /js/search.js
  $("#check_all").click(function(event){
	event.stopPropagation();
	if($("#check_all").is(":checked")){
		$("input:checkbox").prop('checked', 'checked');
	}else{
		$("input:checkbox").prop('checked',false); 
	}
});
$("input:checkbox").click(function(event){
	event.stopPropagation();
});
$(".search_form input:checkbox").click(function(event){
	var len= $(".search_form input:checkbox:checked").length;
	if(len>0)$("#sol").css("display","");
	else $("#sol").css("display","none");
	$("#selected").html("("+ len+")");
	
});
$(".checkbox").click(function(event){
	event.stopPropagation();
});
$("#statement_button").click(function(event){
	//alert(111);
	var str= collechSearchCondition();
	if(str.indexOf("&filter_empty=1")>0)alert("\t Фильтр пуст.\n Измените значения параметров.")
	else{
        $("#statement").load("./statement?"+collechSearchCondition());
	    $("#statement" ).toggle( "fast" );
    }
});
$("#client_filter_div").load("./clientFilters");

});
/*
var ajaxUpdateTimeout;
var ajaxRequest;
$('input#string').keyup(function(){
/ajaxRequest = $(this).serialize();
clearTimeout(ajaxUpdateTimeout);
ajaxUpdateTimeout = setTimeout(function () {
$.fn.yiiListView.update(
// this is the id of the CListView
'ajaxListView',
{
url: '" . CController::createUrl('persons/persearch') . "',
data: ajaxRequest
}
)
},
// this is the delay
300);
});
*/

</script>
<?php
$month = array("январь","февраль","март","апрель","май","июнь","июль","август","сентябрь","октябрь","ноябрь","декабрь","январь","февраль");
$monthnow = date("n");
$class_arr = Cases::$a_types;
?>
<div class='row type3' id='statement' style='z-index:100;padding-left:10px;'></div>
<table><tr><td class='filter'>
<table
<tr>
<td id='shift'><div id='shiftcontent' style='height:950px;'>>></div></td>
<td class='filterform'>
<div id='filter' style='display:;width:250px;'>
<h4 width='100%' style='background:black;color:white;'>&nbsp;фильтр</h4>
<center>
<h6>Клиентские фильтры <b id='statement_button'>+</b>
</h6>
<div id='client_filter_div'></div>
<h6 width='100%' style='margin-top:1em;'>&nbsp;&nbsp;80 лет</h6>
<table class='eighty'>
<tr><td num='0' style='background:#fdd;'><?php echo $month[$monthnow-1];?>
</td>
<td num='1' style='background:#ffd;'><?php echo $month[$monthnow];?>
</td>
<td num='2' style='background:#dfd;'><?php echo $month[$monthnow+1];?>
</td>
</tr>
</table>
  <label for="amount" style='margin-top: 0em;font-size:18px;'>Возраст:</label>
  <nobr>&nbsp;<input type="text" id="amount" readonly style="border:0; color:#555; font-weight:bold;"></nobr>
<div id="slider-range" width='90%' style='margin:0.5em 1em 0em 1em;'></div>
<div id="format">
<?php 
$typestr = $conditions["type"];
foreach($class_arr as $k=>$one){
	$s = strpos($conditions["type"],$one) !== false ? " checked" : "";
	//echo $one.$s;
	echo '<input type="checkbox" id="'.$one.'" '.$s.'><label style="font-size:12px;width:40px;" for="'.$one.'">'.$k.'</label>';
}
?>
 </div>


<div id='gender'>
<input type="checkbox" id="male" <?php echo $conditions["gender"] == "male"?" checked":""?>><label style="font-size:12px;width:40px;" for="male">Муж</label>
<input type="checkbox" id="female"  <?php echo $conditions["gender"] == "female"?" checked":""?>><label style="font-size:12px;width:40px;" for="female">Жен</label>
</div>

<div id='warchaes'>
 <input type="checkbox" id="checkwar" <?php echo $conditions["war"]?" checked":""?>><label style="font-size:12px;" for="checkwar">Участник БД 
</label>
<input type="checkbox" id="checkchaes" <?php echo $conditions["chaes"]?" checked":""?>><label style="font-size:12px;" for="checkchaes">ЧАЭС 
</label>
</div>
<div id='term'>
 <input type="checkbox" id="terminated" <?php echo $conditions["terminated"]?" checked":""?>><label style="font-size:12px;" for="terminated">Законченные
</label>
</div>

<div id='paystop_div'>
<input type="checkbox" id="paystop" <?php echo $conditions["paystop"]?" checked":""?>><label style="font-size:12px;margin:0em 1em 1em 1em;" for="paystop">Заканчиваются выплаты в следующем месяце 
</label>
</div>

<div id='showall_div' >
<input type="checkbox" id="showall"><label style="font-size:12px;" for="showall" style='margin:0em 1em 1em 1em;'>Отобразить все страницы
</label>
</div>
</center>
</div>
</td>
</tr>
</table>
</td>
<td>
<div id='result' style='border:3px double white;padding:10px;display:none;position:absolute;background:#ffd;top:112px;left:10px;width:700px;'></div>
<nobr>
<?php 

$_string  = "";
if(isset($_GET['string'])) $_string = $_GET['string'];
if(isset($conditions["string"])) $_string = $conditions["string"];

$class_arr = Cases::$a_types;
echo CHtml::beginForm("",'get', array('id'=>'filter-form'))
. CHtml::textField('string', $_string, array('id'=>'string','size'=>'50','AUTOCOMPLETE'=>"off"))
. CHtml::button('Новое пенсионное дело', array('submit' => array('create')))
. CHtml::endForm();
?>
</nobr>
<div id='result2'>
<table>
<tr>
<td><font color='#fff'>Всего:<?php echo $count[0]["count"];?></font><font color='#fff' style='text-align:right' id='selected'>(0)</font></td>
<td> <div id="sol" style="display:none"> 
 <select name="files" id="files" >
      <optgroup label="Отчеты">
        <option value="jquery" style="10px">Награждения</option>
        <option value="jqueryui"  style="10px">Созидание</option>
      </optgroup>
      <optgroup label="Справки">
        <option value="somefile"  style="10px">Ослабление</option>
        <option value="someotherfile"  style="10px">Некоторое промозглое ожидание</option>
      </optgroup>
    </select></div>
</td>

</tr></table>
<table class='search_form'>
<?php
if(count($data)){
	$b = ($conditions["anch"] ? $conditions["anch"]-1 : 0)*Cases::$how_many +1;
	$i = 0;
	echo "<th><input type='checkbox' id='check_all'></th><th></th><th></th><th>ВП</th><th>П/дело</th><th>Фамилия</th><th>Имя</th><th>Отчество</th><th><nobr>Дата рождения</nobr></th>";
    foreach($data as $one){
	    echo "<tr num='".$one['id']."'><td class='checkbox'><input type='checkbox' name='n".$one['id']."'></td><td>".$b++."</td><td class='".$class_arr[$one['type']]."'>&nbsp;&nbsp;&nbsp;</td><td>".$one['type']."</td><td>".$one['number']."</td><td> ".$one['second_name']."</td><td> ".$one['first_name']."</td><td> ".$one['third_name']."</td><td>".Yii::app()->dateFormatter->format("dd.MM.y",$one['birth_date'])."</td></tr>";
	
    }
	if($i==10)echo "<tr><td>Всего:". $count[0]["count"]."</td></tr>";
	echo "</table>";
	$page_count =  intval($count[0]["count"]/Cases::$how_many);
	if($page_count>2  && ($conditions["showall"] !== 1)){
	    echo "<table  class='paging' style=''><tr>";
	    for($i=1;$i<=$page_count;$i++){
			$class = $conditions["anch"] == $i ? "active" : "";
		    echo "<td num='".$i."' class='".$class."'> ".$i."</td>";
			if($i==10){
				echo "<td num='2'>      Следующие>></td>";
				break;
			}
	    }
	    echo "</tr></table>";
	}
}else{
	echo "<tr><td>результатов нет</td></tr></table>
";
}

?>
</div>
</td></tr>
</table>
