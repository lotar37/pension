<?php 
class Calc{
public function calc(){
	echo "Hello world!!!";
	
}

}