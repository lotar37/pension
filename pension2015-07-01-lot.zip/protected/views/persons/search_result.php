<script>
$("table.search_form tr").mouseover(function(){
	$(this).addClass("actform");
});
$("table.search_form tr").mouseout(function(){
	$(this).removeClass("actform");
});
$("table.search_form tr").click(function(event){
		event.stopPropagation();
	    window.document.location.href='update/'+$(this).attr("num");	
});
$(".paging td").click(function(event){
	//alert($(this).attr("num"));
	
     ajaxRequest = $("#string").serialize();
     $('div#result2').load('loadSearchResult?'+ajaxRequest+"&noCache=" + (new Date().getTime()) + Math.random()+collechSearchCondition()+"&anch="+$(this).attr("num"));
});
$("#check_all").click(function(event){
	event.stopPropagation();
	if($("#check_all").is(":checked")){
		$("input:checkbox").prop('checked', 'checked');
	}else{
		$("input:checkbox").prop('checked',false); 
	}
});
$("input:checkbox").click(function(event){
	event.stopPropagation();
});
$(".search_form input:checkbox").click(function(event){
	var len= $(".search_form input:checkbox:checked").length;
	if(len>0)$("#sol").css("display","");
	else $("#sol").css("display","none");
	$("#selected").html("("+ len+")");
	
});
$(".checkbox").click(function(event){
	event.stopPropagation();
});
   // $( "#files" ).selectmenu();

</script>
<style>
    fieldset {
      border: 0;
    }
    label {
      display: block;
      margin: 30px 0 0 0;
 	  font-size:12px;
   }
    select {
      width: 200px;
	  height:20px;
	  font-size:12px;
    }
	option{
	  font-size:6pt;
		
	}
    .overflow {
      height: 200px;
    }
	.paging{
	border-spacing: 7px;
	width:200px;
}
.paging td{
	padding:5px;
	margin:5px;
	!background:#ddd;
	cursor:pointer;
	vertical-align:center;
	color:#fff;
}
.paging td.active{
	padding:5px;
	margin:5px;
	cursor:pointer;
	font-weight:bold;
	font-size: 24px;
}
</style>
<table>
<tr>
<td><nobr><font color='#fff'>Всего:<?php echo $count[0]["count"];?></font>
<font color='#fff' style='text-align:right' id='selected'>(0)</font></nobr></td>
<td> <div id="sol" style="display:none"> 
 <select name="files" id="files" >
      <optgroup label="Отчеты">
        <option value="jquery" style="10px">Награждения</option>
        <option value="jqueryui"  style="10px">Созидание</option>
      </optgroup>
      <optgroup label="Справки">
        <option value="somefile"  style="10px">Ослабление</option>
        <option value="someotherfile"  style="10px">Некоторое промозглое ожидание</option>
      </optgroup>
    </select></div>
</td>
</tr></table>
<table class='search_form'>
<?php


$class_arr = Cases::$a_types;
if(!isset($conditions))$conditions=array("anch"=>1,"showall"=>0);
if(count($data)){
	
	echo "<th><input type='checkbox' id='check_all'></th><th>№</th><th></th><th>ВП</th><th>П/дело</th><th>Фамилия</th><th>Имя</th><th>Отчество</th><th>Дата рождения</th>";
	$i = 0;
	$b = ($conditions["anch"] ? $conditions["anch"]-1 : 0)*Cases::$how_many+1;
    foreach($data as $one){
	    echo "<tr num='".$one['id']."'><td class='checkbox'><input type='checkbox' name='n".$one['id']."'></td><td>".$b++."</td><td class='".$class_arr[$one['type']]."'>&nbsp;&nbsp;&nbsp;</td><td>".$one['type']."</td><td>".$one['number']."</td><td> ".$one['second_name']."</td><td> ".$one['first_name']."</td><td> ".$one['third_name']."</td><td> ".Yii::app()->dateFormatter->format("dd.MM.y",$one['birth_date'])." </td></tr>";
		
		if(++$i>1500)break;
    }
	echo "</table>";
	 $page_count =  intval($count[0]["count"]/Cases::$how_many) +1;
	 
	if($page_count>=2 && ($conditions["showall"] !== 1)){
		$i_begin = $conditions["anch"]>6 ? $conditions["anch"] - 5 : 1;
		$i_end = $i_begin + 9;
	    echo "<table  class='paging' style=''><tr>";
		if($conditions["anch"]>1)echo "<td num='".($conditions["anch"]-1)."'>      <<Предыдущие</td>";
		
	    for($i=$i_begin;$i<=$page_count;$i++){
			$class = $conditions["anch"] == $i ? "active" : "";
		    echo "<td num='".$i."' class='".$class."'> ".$i."</td>";
			if($i==$i_end){
				echo "<td num='".($conditions["anch"]+1)."'>      Следующие>></td>";
				break;
			}
	    }
	    echo "</tr></table>";
	}
}else{
	echo "<tr><td>результатов нет</td></tr>";
}
	echo "</table>";

?>

