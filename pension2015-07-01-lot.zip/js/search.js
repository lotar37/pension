  function collechSearchCondition(){
	  if(!$('#filter').is(':visible'))return "";
	  //pension types
      $("#h1_title").text("Пенсионные дела");
	  var s_types   = "";
	  var s_age     = "";
	  var s_war     = "";
	  var s_chaes   = "";
	  var s_showall = "";
	  var s_paystop = "";
	  var s_gender  = "";
	  var s_terminated  = "";
	  var filter_empty = "";
	  var i = 0; 
      $("#format input:checkbox:checked").each(function(index, elem){
		s_types +=  (s_types ? "_" : "") + $(elem).prop("id");  
		i++;
      }); 
	  //if everyone or no one is selected
	  if(i==0 || i==6){
		  s_types = "";
	  }
	  var i = 0; 
      $("#gender input:checkbox:checked").each(function(index, elem){
		s_gender +=  (s_gender ? "_" : "") + $(elem).prop("id");  
		i++;
      }); 
	  //if everyone or no one is selected
	  if(i==0 || i==2){
		  s_gender = "";
	  }
	  
	  if($("#checkwar").is(":checked"))s_war = 1;
	  if($("#checkchaes").is(":checked"))s_chaes = 1;
	  if($("#showall").is(":checked"))s_showall = 1;
	  if($("#paystop").is(":checked"))s_paystop = 1;
	  if($("#terminated").is(":checked"))s_terminated = 1;
	  s_age =  $( "#slider-range" ).slider( "values", 0 ) + "-" + $( "#slider-range" ).slider( "values", 1 );
	  //alert("&type="+ s_types.trim()+"&age="+s_age.trim()+"&war="+s_war+"&chaes="+s_chaes+"&showall="+s_showall+"&paystop="+s_paystop+"&gender="+s_gender);
	 if(
	  (s_types   == "") &&
	  (s_age     == "0-120") &&
	  (s_war     == "") &&
	  (s_chaes   == "") &&
	  (s_showall == "") &&
	  (s_paystop == "") &&
	  (s_gender  == "") 
	)
	{
	    filter_empty = 1;
    }
	 return "&type="+ s_types.trim()+"&age="+s_age.trim()+"&war="+s_war+"&chaes="+s_chaes+"&showall="+s_showall+"&paystop="+s_paystop+"&gender="+s_gender+"&terminated="+s_terminated+"&filter_empty="+filter_empty + "&filter_change=1";
  }
 