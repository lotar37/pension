<?
class DBAuthManager extends CDbAuthManager
{
	public $installPass='123456';
	
}


?>
